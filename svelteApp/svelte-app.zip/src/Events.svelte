<script>
	let jokiEvents = [];
	let initialized = false;
	
	function init() {
		initialized = true;
		window.addEventListener("message", eventHandler);
		window.postMessage({type: "JOKIDT_DEVTOOL", key: "getEvents"}, "*");	
		
	}
	
	function eventHandler(event) {
		const data = event.data;
		console.log("Svelte Events, event handler", data);
		if(data.type === "JOKIDT_EVENTS") {
			if(Array.isArray(data.data)) {
				jokiEvents = data.data;
			}
		}
	}
	
	!initialized && init();
	
	onDestroy( ()=> {
		window.removeEventListener("message", eventHandler);
	});
</script>

<style>
	div.joki-event {
		margin-bottom: 1rem;
	}
	
	div.joki-event > p {
		margin: 0;
		padding: 0;
	}
</style>

<h1>
	Events
</h1>

{#if jokiEvents.length === 0}
<p>
	No Joki events found
</p>
{/if}

{#each jokiEvents as jokiEvent}
<div class="joki-event">
	<p>
		From:{jokiEvent.from}
	</p>
	<p>
		Key:{jokiEvent.key}
	</p>
	<p>
		To: {jokiEvent.to}
	</p>
</div>
{/each}