<script>
	import Services from './Services.svelte';
	import Events from './Events.svelte';
	import Summary from './Summary.svelte';
	
	let openView = Summary;
	
	function changeView(value) {
		openView = value;
	}
</script>

<nav>
	<button on:click={() => changeView(Summary)}>
		State
	</button>
	
	<button on:click={() => changeView(Events)}>
		Joki Events
	</button>
	
	<button on:click={() => changeView(Services)}>
		Services
	</button>
</nav>

<svelte:component this={openView} />